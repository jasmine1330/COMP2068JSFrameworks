// routes/index.js
const express = require('express');
const router = express.Router();

router.get('/', function(req, res, next) {
    res.render('index');
});

router.get('/pet1', function(req, res, next) {
    res.render('pet1');
});

router.get('/pet2', function(req, res, next) {
    res.render('pet2');
});

router.get('/pet3', function(req, res, next) {
    res.render('pet3');
});

router.get('/pet4', function(req, res, next) {
    res.render('pet4');
});

module.exports = router;
